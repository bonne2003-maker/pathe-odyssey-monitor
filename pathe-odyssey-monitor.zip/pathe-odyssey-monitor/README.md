# Pathé Odyssey IMAX monitor

Deze repository controleert elke 15 minuten de officiële Pathé-website voor **The Odyssey** in **IMAX bij Pathé Arena Amsterdam**.

Doel: minstens twee vrije stoelen direct naast elkaar in **rij 1 t/m 12**, met voorkeur voor de lagere rijnummers (verder naar achteren) en daarna zo centraal mogelijk.

## Bestanden

- `checker.js` — opent de officiële Pathé-boekingsflow met Playwright en leest de stoelkaart uit.
- `status.json` — laatste betrouwbare controle.
- `index.html` — statusscherm met afteller tot het volgende kwartier.
- `.github/workflows/check.yml` — draait automatisch elke 15 minuten.

De checker is bewust conservatief: als Pathé de stoelkaart niet betrouwbaar exposeert, wordt de status `unverified` in plaats van dat beschikbaarheid wordt gegokt.

## GitHub Pages

Zet GitHub Pages aan via **Settings → Pages → Deploy from a branch → main / (root)**. Daarna staat het dashboard op de Pages-URL van deze repository.
