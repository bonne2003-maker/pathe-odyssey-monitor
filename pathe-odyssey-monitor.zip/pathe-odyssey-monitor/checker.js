const { chromium } = require('playwright');
const fs = require('fs');

const CINEMA_URL = 'https://www.pathe.nl/nl/bioscopen/pathe-arena';
const TARGET_DATES = [
  { iso: '2026-08-14', labels: [/morgen/i, /tomorrow/i, /14\s*aug/i, /fri(?:day)?\s*14\s*aug/i, /vr(?:ijdag)?\s*14\s*aug/i] },
  { iso: '2026-08-15', labels: [/15\s*aug/i, /sat(?:urday)?\s*15\s*aug/i, /za(?:terdag)?\s*15\s*aug/i] },
  { iso: '2026-08-16', labels: [/16\s*aug/i, /sun(?:day)?\s*16\s*aug/i, /zo(?:ndag)?\s*16\s*aug/i] },
];
const MIN_ROW = 1;
const MAX_ROW = 12;

function nowIso() {
  return new Date().toISOString();
}

function parseSeatLabel(label) {
  if (!label) return null;
  const normalized = String(label).replace(/\s+/g, ' ').trim();
  const rowMatch = normalized.match(/(?:rij|row)\s*[:#-]?\s*(\d{1,2})/i);
  const seatMatch = normalized.match(/(?:stoel|seat|plaats)\s*[:#-]?\s*(\d{1,3})/i);
  if (!rowMatch || !seatMatch) return null;
  return { row: Number(rowMatch[1]), seat: Number(seatMatch[1]), label: normalized };
}

function findAdjacentPair(seats) {
  const byRow = new Map();
  for (const seat of seats) {
    if (seat.row < MIN_ROW || seat.row > MAX_ROW) continue;
    if (!byRow.has(seat.row)) byRow.set(seat.row, []);
    byRow.get(seat.row).push(seat.seat);
  }

  const candidates = [];
  for (const [row, numbers] of byRow.entries()) {
    const unique = [...new Set(numbers)].sort((a, b) => a - b);
    if (unique.length < 2) continue;
    const center = (unique[0] + unique[unique.length - 1]) / 2;
    for (let i = 0; i < unique.length - 1; i++) {
      if (unique[i + 1] === unique[i] + 1) {
        const pairCenter = (unique[i] + unique[i + 1]) / 2;
        candidates.push({
          row,
          seats: [unique[i], unique[i + 1]],
          score: row * 100 + Math.abs(pairCenter - center),
        });
      }
    }
  }
  candidates.sort((a, b) => a.score - b.score);
  return candidates[0] || null;
}

async function acceptCookies(page) {
  const patterns = [/alles accepteren/i, /accepteer alles/i, /accept all/i, /akkoord/i];
  for (const pattern of patterns) {
    const button = page.getByRole('button', { name: pattern }).first();
    if (await button.isVisible().catch(() => false)) {
      await button.click().catch(() => {});
      await page.waitForTimeout(500);
      break;
    }
  }
}

async function clickDate(page, date) {
  for (const pattern of date.labels) {
    const candidates = [
      page.getByRole('button', { name: pattern }).first(),
      page.getByRole('link', { name: pattern }).first(),
      page.getByText(pattern).first(),
    ];
    for (const locator of candidates) {
      if (await locator.isVisible().catch(() => false)) {
        await locator.click().catch(() => {});
        await page.waitForLoadState('domcontentloaded').catch(() => {});
        await page.waitForTimeout(1200);
        return true;
      }
    }
  }
  return false;
}

async function collectOdysseyImaxShowtimes(page) {
  return page.evaluate(() => {
    const timeRegex = /^(?:[01]?\d|2[0-3]):[0-5]\d$/;
    const out = [];
    const interactive = [...document.querySelectorAll('a, button, [role="button"]')];

    for (const el of interactive) {
      const text = (el.textContent || '').replace(/\s+/g, ' ').trim();
      if (!timeRegex.test(text)) continue;

      let node = el;
      let context = '';
      for (let i = 0; i < 9 && node; i++, node = node.parentElement) {
        context = (node.textContent || '').replace(/\s+/g, ' ').trim();
        if (/the odyssey/i.test(context)) break;
      }
      if (!/the odyssey/i.test(context)) continue;

      // Require IMAX near the showtime to avoid checking non-IMAX sessions.
      let local = el;
      let imaxContext = '';
      for (let i = 0; i < 5 && local; i++, local = local.parentElement) {
        imaxContext = (local.textContent || '').replace(/\s+/g, ' ').trim();
        if (/imax/i.test(imaxContext)) break;
      }
      if (!/imax/i.test(imaxContext) && !/imax/i.test(context)) continue;

      const href = el.tagName === 'A' ? el.href : null;
      out.push({ time: text, href, text: context.slice(0, 600) });
    }

    return out.filter((item, idx, arr) =>
      arr.findIndex(x => x.time === item.time && x.href === item.href) === idx
    );
  });
}

async function openShowtime(page, showtime) {
  if (showtime.href) {
    await page.goto(showtime.href, { waitUntil: 'domcontentloaded', timeout: 45000 });
    await page.waitForTimeout(1800);
    return page.url();
  }

  const timeLocator = page.getByText(showtime.time, { exact: true }).first();
  if (!(await timeLocator.isVisible().catch(() => false))) return null;
  await Promise.all([
    page.waitForLoadState('domcontentloaded', { timeout: 15000 }).catch(() => {}),
    timeLocator.click(),
  ]);
  await page.waitForTimeout(1800);
  return page.url();
}

async function extractAvailableSeats(page) {
  return page.evaluate(() => {
    const negative = /(occupied|unavailable|reserved|taken|sold|disabled|bezet|niet beschikbaar|gereserveerd)/i;
    const positive = /(available|beschikbaar|free|vrij|seat|stoel|plaats)/i;
    const nodes = [...document.querySelectorAll('button, [role="button"], [aria-label], [title], [data-seat], [data-seat-number]')];
    const seats = [];

    function parse(label) {
      const normalized = String(label || '').replace(/\s+/g, ' ').trim();
      const rowMatch = normalized.match(/(?:rij|row)\s*[:#-]?\s*(\d{1,2})/i);
      const seatMatch = normalized.match(/(?:stoel|seat|plaats)\s*[:#-]?\s*(\d{1,3})/i);
      if (!rowMatch || !seatMatch) return null;
      return { row: Number(rowMatch[1]), seat: Number(seatMatch[1]), label: normalized };
    }

    for (const el of nodes) {
      const labels = [
        el.getAttribute('aria-label'),
        el.getAttribute('title'),
        el.getAttribute('data-label'),
        el.getAttribute('data-seat'),
        el.textContent,
      ].filter(Boolean);
      const joined = labels.join(' | ');
      const parsed = parse(joined);
      if (!parsed) continue;

      const descriptor = [
        joined,
        el.className && String(el.className),
        el.getAttribute('data-status'),
        el.getAttribute('aria-disabled'),
      ].filter(Boolean).join(' ');

      const disabled =
        el.hasAttribute('disabled') ||
        el.getAttribute('aria-disabled') === 'true' ||
        negative.test(descriptor);

      // Conservative rule: only count enabled seat controls, or seats explicitly marked available/free.
      const enabledInteractive =
        (el.tagName === 'BUTTON' || el.getAttribute('role') === 'button') && !disabled;
      const explicitlyAvailable = positive.test(descriptor) && !negative.test(descriptor) && !disabled;

      if (enabledInteractive || explicitlyAvailable) {
        seats.push(parsed);
      }
    }

    const unique = [];
    const seen = new Set();
    for (const seat of seats) {
      const key = `${seat.row}-${seat.seat}`;
      if (!seen.has(key)) {
        seen.add(key);
        unique.push(seat);
      }
    }
    return unique;
  });
}

async function inspectShowtime(browser, dateIso, showtime) {
  const context = await browser.newContext({
    locale: 'nl-NL',
    timezoneId: 'Europe/Amsterdam',
    viewport: { width: 1440, height: 1100 },
  });
  const page = await context.newPage();
  const result = {
    date: dateIso,
    time: showtime.time,
    bookingUrl: showtime.href,
    status: 'unknown',
    availableSeatCount: 0,
    pair: null,
  };

  try {
    await page.goto(CINEMA_URL, { waitUntil: 'domcontentloaded', timeout: 45000 });
    await acceptCookies(page);
    const date = TARGET_DATES.find(d => d.iso === dateIso);
    await clickDate(page, date);

    const currentShowtimes = await collectOdysseyImaxShowtimes(page);
    const match = currentShowtimes.find(s => s.time === showtime.time) || showtime;
    const bookingUrl = await openShowtime(page, match);
    if (bookingUrl) result.bookingUrl = bookingUrl;

    await acceptCookies(page);
    await page.waitForTimeout(1200);
    const seats = await extractAvailableSeats(page);
    result.availableSeatCount = seats.length;

    if (seats.length < 2) {
      result.status = 'seat_map_unreadable';
      return result;
    }

    const pair = findAdjacentPair(seats);
    if (pair) {
      result.status = 'pair_found';
      result.pair = pair;
    } else {
      result.status = 'no_pair';
    }
    return result;
  } catch (error) {
    result.status = 'error';
    result.error = String(error && error.message ? error.message : error).slice(0, 500);
    return result;
  } finally {
    await context.close();
  }
}

async function main() {
  const status = {
    checkedAt: nowIso(),
    source: 'official Pathé website',
    cinema: 'Pathé Arena Amsterdam',
    film: 'The Odyssey',
    format: 'IMAX',
    rows: '1-12',
    state: 'checking',
    found: false,
    best: null,
    checks: [],
    diagnostics: [],
  };

  const browser = await chromium.launch({ headless: true });
  try {
    const discoveryContext = await browser.newContext({
      locale: 'nl-NL',
      timezoneId: 'Europe/Amsterdam',
      viewport: { width: 1440, height: 1100 },
    });
    const page = await discoveryContext.newPage();

    for (const date of TARGET_DATES) {
      try {
        await page.goto(CINEMA_URL, { waitUntil: 'domcontentloaded', timeout: 45000 });
        await acceptCookies(page);
        const dateSelected = await clickDate(page, date);
        const showtimes = await collectOdysseyImaxShowtimes(page);
        status.diagnostics.push({ date: date.iso, dateSelected, showtimesFound: showtimes.length });

        for (const showtime of showtimes) {
          const result = await inspectShowtime(browser, date.iso, showtime);
          status.checks.push(result);
        }
      } catch (error) {
        status.diagnostics.push({ date: date.iso, error: String(error.message || error).slice(0, 400) });
      }
    }
    await discoveryContext.close();

    const hits = status.checks.filter(c => c.status === 'pair_found' && c.pair);
    if (hits.length) {
      hits.sort((a, b) => a.pair.score - b.pair.score || a.date.localeCompare(b.date) || a.time.localeCompare(b.time));
      status.state = 'pair_found';
      status.found = true;
      status.best = hits[0];
    } else if (status.checks.some(c => c.status === 'no_pair')) {
      status.state = 'no_pair';
    } else {
      status.state = 'unverified';
    }
  } finally {
    await browser.close();
    status.checkedAt = nowIso();
    fs.writeFileSync('status.json', JSON.stringify(status, null, 2) + '\n');
    console.log(JSON.stringify(status, null, 2));
  }
}

main().catch(error => {
  const status = {
    checkedAt: nowIso(),
    state: 'error',
    found: false,
    error: String(error && error.stack ? error.stack : error).slice(0, 1500),
  };
  fs.writeFileSync('status.json', JSON.stringify(status, null, 2) + '\n');
  console.error(error);
  process.exitCode = 1;
});
